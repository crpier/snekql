"""Private-worktree calibration of public CLI selection; same approved seam."""
import ast,hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
r=Path(__file__).parent;cwd=r/'calibration-src';files=['tests/test_docs_cli.py','tests/test_runtime_selection.py','tests/testing/mariadb/test_cli.py'];controls={'tests/test_runtime_selection.py::runtime_config_resolution_returns_backend_configs','tests/test_runtime_selection.py::runtime_config_resolution_rejects_unsupported_or_ambiguous_input'}
for s in (signal.SIGINT,signal.SIGQUIT,signal.SIGHUP):signal.signal(s,signal.SIG_DFL)
original={p:(cwd/p).read_bytes() for p in files};meta={'candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Marker metadata only in owned private worktree. Selected cases pass; independent routing oracle must reject wrong sets. Live SDK/test sources never mutated.','bytecode_policy':'Delete only changed test modules owned pyc before each command; PYTHONDONTWRITEBYTECODE=1 avoids same-sized/timestamp alias.','runs':[],'faults':[]}
def run(label,extra=(),selection=None):
 for p in files:
  for cache in (cwd/Path(p).parent/'__pycache__').glob(Path(p).stem+'.*.pyc'):cache.unlink()
 tmp=r/f'c{len(meta["runs"]):02d}';tmp.mkdir();cmd=[sys.executable,'-m','snektest',*(selection or files),*extra,'--json-output'];start=time.monotonic()
 with (r/f'{label}.json').open('wb') as out,(r/f'{label}.stderr').open('wb') as err:p=subprocess.run(cmd,cwd=cwd,env={**os.environ,'TMPDIR':str(tmp),'PYTHON_CONTEXT_AWARE_WARNINGS':'1','PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err,check=False)
 d=json.loads((r/f'{label}.json').read_text());meta['runs'].append({'label':label,'cwd':str(cwd),'command':cmd,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start,'TMPDIR':str(tmp),'counts':{k:d[k] for k in ('passed','failed','errors','fixture_teardown_failed','session_teardown_failed')},'report_sha256':hashlib.sha256((r/f'{label}.json').read_bytes()).hexdigest()});assert p.returncode==0 and not any(d[k] for k in ('failed','errors','fixture_teardown_failed','session_teardown_failed'));assert not(r/f'{label}.stderr').stat().st_size;assert not list(tmp.iterdir());assert not[l for l in subprocess.check_output(['ps','-eo','pid,args'],text=True).splitlines() if str(tmp) in l];tmp.rmdir();return{t['name'] for t in d['tests']}
def change(path,name,value):
 source=(cwd/path).read_text();fn=next(f for f in ast.parse(source).body if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)) and f.name==name);mark=next(k.value for d in fn.decorator_list if isinstance(d,ast.Call) for k in d.keywords if k.arg=='mark');assert mark.lineno==mark.end_lineno;lines=source.splitlines(keepends=True);line=lines[mark.lineno-1];lines[mark.lineno-1]=line[:mark.col_offset]+repr(value)+line[mark.end_col_offset:];(cwd/path).write_text(''.join(lines))
for label,path,name,value in [('fault-cli-fast',files[0],'docs_cli_prints_agent_docs','fast'),('fault-pure-slow',files[1],'runtime_config_resolution_returns_backend_configs','slow')]:
 try:
  change(path,name,value);observed=run(label,['--mark','fast'])
  try:assert observed==controls,'Wrong public fast selection'
  except AssertionError as e:rejected=str(e)
  else:raise AssertionError('Routing fault escaped')
  assert (len(observed)==3 and observed-controls=={'tests/test_docs_cli.py::docs_cli_prints_agent_docs'}) if value=='fast' else (len(observed)==1 and controls-observed=={'tests/test_runtime_selection.py::runtime_config_resolution_returns_backend_configs'})
  meta['faults'].append({'label':label,'oracle_rejected':rejected,'selected_names':sorted(observed),'missing':sorted(controls-observed),'extra':sorted(observed-controls)});print(label,'rejected',len(observed),flush=True)
 finally:
  for p,raw in original.items():(cwd/p).write_bytes(raw)
 assert run(label+'-restored',['--mark','fast'])==controls
assert run('restored-cold-cli',['--mark','slow'],['tests/test_docs_cli.py::docs_cli_prints_agent_docs'])=={'tests/test_docs_cli.py::docs_cli_prints_agent_docs'}
assert all((cwd/p).read_bytes()==raw for p,raw in original.items());assert subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True)=='';meta['restored_sha256']={p:hashlib.sha256(raw).hexdigest() for p,raw in original.items()};meta['source_restored_byte_for_byte']=True;(r/'routing-calibration.json').write_text(json.dumps(meta,indent=2)+'\n');(r/'routing-calibration.status').write_text('0\n')
