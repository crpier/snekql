"""One-off public CLI routing proof. No framework internals or SDK mutation."""
import ast,hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
r=Path(__file__).parent
files=['tests/test_docs_cli.py','tests/test_runtime_selection.py','tests/testing/mariadb/test_cli.py']
controls={'tests/test_runtime_selection.py::runtime_config_resolution_returns_backend_configs','tests/test_runtime_selection.py::runtime_config_resolution_rejects_unsupported_or_ambiguous_input'}
for sig in (signal.SIGINT,signal.SIGQUIT,signal.SIGHUP):signal.signal(sig,signal.SIG_DFL)
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
original={p:Path(p).read_text() for p in files}
meta={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Reuse confirmed public CLI/filter/mark/JSON seam; routing reds reject selection while original assertions pass. No speedup claim.','controls':sorted(controls),'runs':[],'cycles':[],'original_sha256':{p:hashlib.sha256(s.encode()).hexdigest() for p,s in original.items()}}
def marker(fn):
 return next((k.value for d in fn.decorator_list if isinstance(d,ast.Call) and isinstance(d.func,ast.Name) and d.func.id=='test' for k in d.keywords if k.arg=='mark'),None)
def normalize(source):
 tree=ast.parse(source)
 for fn in tree.body:
  if isinstance(fn,(ast.FunctionDef,ast.AsyncFunctionDef)):
   m=marker(fn)
   if isinstance(m,ast.Constant):m.value='resource-marker'
 return ast.dump(tree,include_attributes=False)
def run(label,extra=(),selection=None):
 for p in files:
  for cache in (Path(p).parent/'__pycache__').glob(Path(p).stem+'.*.pyc'):cache.unlink()
 tmp=r/f'q{len(meta["runs"]):03d}';tmp.mkdir();cmd=[sys.executable,'-m','snektest',*(selection or files),*extra,'--json-output'];start=time.monotonic()
 with (r/f'{label}.json').open('wb') as out,(r/f'{label}.stderr').open('wb') as err:p=subprocess.run(cmd,stdout=out,stderr=err,env={**os.environ,'TMPDIR':str(tmp),'PYTHON_CONTEXT_AWARE_WARNINGS':'1','PYTHONDONTWRITEBYTECODE':'1'},check=False)
 d=json.loads((r/f'{label}.json').read_text());entry={'label':label,'command':cmd,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start,'TMPDIR':str(tmp),'PYTHON_CONTEXT_AWARE_WARNINGS':'1','PYTHONDONTWRITEBYTECODE':'1','counts':{k:d[k] for k in ('passed','failed','errors','fixture_teardown_failed','session_teardown_failed')},'report_sha256':hashlib.sha256((r/f'{label}.json').read_bytes()).hexdigest()};meta['runs'].append(entry);(r/'routing-tdd.json').write_text(json.dumps(meta,indent=2)+'\n');assert p.returncode==0 and not any(d[k] for k in ('failed','errors','fixture_teardown_failed','session_teardown_failed'));assert not(r/f'{label}.stderr').stat().st_size;assert not list(tmp.iterdir());assert not [l for l in subprocess.check_output(['ps','-eo','pid,args'],text=True).splitlines() if str(tmp) in l];tmp.rmdir();names={t['name'] for t in d['tests']};assert len(names)==len(d['tests'])==d['passed'];return names
all_names=run('before-all');expected_fast=run('before-fast',['--mark','fast']);assert len(all_names)==23 and len(expected_fast)==15 and controls<=expected_fast
targets=[]
for p,source in original.items():
 for fn in ast.parse(source).body:
  if isinstance(fn,(ast.FunctionDef,ast.AsyncFunctionDef)):
   m=marker(fn)
   if isinstance(m,ast.Constant) and m.value=='fast' and f'{p}::{fn.name}' not in controls:targets.append((p,fn.name))
assert len(targets)==11
for index,(p,name) in enumerate(targets):
 prefix=f'{p}::{name}';producer={n for n in all_names if n==prefix or n.startswith(prefix+'[')};assert producer
 red=run(f'route-{index:02d}-red',['--mark','fast']);assert red==expected_fast and controls<=red
 try:assert not(red&producer),'Subprocess-backed producer is still selected by --mark fast'
 except AssertionError as error:red_reason=str(error)
 else:raise AssertionError('Expected routing red absent')
 source=Path(p).read_text();fn=next(f for f in ast.parse(source).body if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)) and f.name==name);m=marker(fn);assert m.value=='fast' and m.lineno==m.end_lineno;lines=source.splitlines(keepends=True);line=lines[m.lineno-1];assert line[m.col_offset:m.end_col_offset]=='"fast"';lines[m.lineno-1]=line[:m.col_offset]+'"slow"'+line[m.end_col_offset:];Path(p).write_text(''.join(lines));assert normalize(original[p])==normalize(Path(p).read_text())
 expected_fast-=producer;green=run(f'route-{index:02d}-green',['--mark','fast']);assert green==expected_fast and controls<=green and not green&producer;slow=run(f'route-{index:02d}-cold-slow',['--mark','slow'],[prefix]);assert slow==producer
 meta['cycles'].append({'file':p,'function':name,'case_names':sorted(producer),'routing_red':red_reason});(r/'routing-tdd.json').write_text(json.dumps(meta,indent=2)+'\n');print(prefix,'red -> green -> cold slow',len(producer),flush=True)
after=run('after-all');fast=run('after-fast',['--mark','fast']);slow=run('after-slow',['--mark','slow']);assert after==all_names and fast==controls and len(slow)==21 and not fast&slow and fast|slow==after;meta['final']={'unfiltered':len(after),'fast':len(fast),'slow':len(slow),'identical_names':True,'partition_complete_disjoint':True,'only_marker_ast_changed':all(normalize(s)==normalize(Path(p).read_text()) for p,s in original.items()),'new_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files}};(r/'routing-tdd.json').write_text(json.dumps(meta,indent=2)+'\n');(r/'routing-tdd.status').write_text('0\n');print(meta['final'],flush=True)
