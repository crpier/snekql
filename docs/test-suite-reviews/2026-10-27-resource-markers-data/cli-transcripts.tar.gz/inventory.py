"""Read-only candidate discovery; not a resource proof or maintained checker."""
import ast,collections,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).parent
rows=[];modules=[]
def dotted(n):
 if isinstance(n,ast.Name):return n.id
 if isinstance(n,ast.Attribute):return dotted(n.value)+'.'+n.attr
 return ''
for path in sorted(Path('tests').rglob('*.py')):
 if '__pycache__' in path.parts:continue
 source=path.read_text();tree=ast.parse(source);found=[]
 for fn in ast.walk(tree):
  if not isinstance(fn,(ast.FunctionDef,ast.AsyncFunctionDef)):continue
  for d in fn.decorator_list:
   if not isinstance(d,ast.Call) or dotted(d.func).split('.')[-1] not in ('test','test_hypothesis'):continue
   marker=next((ast.literal_eval(k.value) for k in d.keywords if k.arg=='mark'),None)
   calls=sorted({dotted(n.func) for n in ast.walk(fn) if isinstance(n,ast.Call)}-{''})
   signals={key:[n for n in calls if any(s in n for s in words)] for key,words in {'process':('run_process','subprocess','Popen','create_subprocess','_run_cli','_run_script','_probe','_run_fresh','_run_python','_run_isolated'),'local_io_threads':('TemporaryDirectory','TemporaryFile','read_text','write_text','read_bytes','write_bytes','open_file','Thread','to_thread','copytree','rmtree','Path.glob','threading','mkdir','unlink'),'database':('initialized_database','Database.initialize','initialize_database','provide_database','provide_mariadb','temporary_mariadb','aiosqlite.connect','sqlite3.connect','aiomysql.connect','create_async_engine'),'fixtures':('load_fixture',)}.items()}
   row={'path':str(path),'function':fn.name,'line':fn.lineno,'decorator':dotted(d.func),'async':isinstance(fn,ast.AsyncFunctionDef),'marker':marker,'signals':{k:v for k,v in signals.items() if v},'calls':calls};rows.append(row);found.append(row)
 if found:modules.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'definitions':len(found),'markers':dict(collections.Counter(x['marker'] or 'unmarked' for x in found))})
report={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'AST definition counts, not expanded case counts. Signals are candidate discovery only, include nested function bodies, miss dynamic/transitive calls and require manual inspection. No collection or execution.','modules':modules,'definitions':rows,'counts':{'test_modules':len(modules),'definitions':len(rows),'markers':dict(collections.Counter(x['marker'] or 'unmarked' for x in rows))}}
(root/'inventory.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['counts'])
for group,predicate in [('fast with process/IO/database signal',lambda r:r['marker']=='fast' and bool(set(r['signals'])-{'fixtures'})),('medium possible external resource',lambda r:r['marker']=='medium' and ('process' in r['signals'] or 'database' in r['signals'])),('unmarked',lambda r:r['marker'] is None)]:
 selected=[r for r in rows if predicate(r)];print('\n',group,len(selected))
 for p,rs in __import__('itertools').groupby(selected,key=lambda r:r['path']):
  rs=list(rs);print(p,len(rs),'; '.join(r['function']+':'+','.join(k for k in r['signals']) for r in rs))
print('\n--- module inventory ---')
for m in modules:print(m['path'],m['definitions'],m['markers'])
