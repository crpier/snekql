"""Calibrate the public CLI oracle in one owned source worktree."""
import ast,hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
r=Path(__file__).parent;cwd=r/'calibration-src';meta={'candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runs':[],'bytecode_policy':'Clear changed test-module pyc before each run and disable bytecode writes to avoid same-size/same-timestamp mutation aliases.'}
for sig in (signal.SIGINT,signal.SIGQUIT,signal.SIGHUP):signal.signal(sig,signal.SIG_DFL)
files=['tests/test_typing_compatibility.py','tests/test_typing_assessment.py'];original={p:(cwd/p).read_bytes() for p in files};expected={t['name'] for t in json.loads((r/'after-typing-fast.json').read_text())['tests']};assert len(expected)==8

def run(label,extra):
 
 for path in files:
  module=cwd/path
  for cache in (module.parent/'__pycache__').glob(module.stem+'.*.pyc'):cache.unlink()
 tmp=r/f'c{len(meta["runs"])}';tmp.mkdir();cmd=[sys.executable,'-m','snektest',*files,*extra,'--json-output'];start=time.monotonic()
 with (r/f'{label}.json').open('wb') as out,(r/f'{label}.stderr').open('wb') as err:p=subprocess.run(cmd,cwd=cwd,env={**os.environ,'TMPDIR':str(tmp),'PYTHON_CONTEXT_AWARE_WARNINGS':'1','PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err,check=False)
 d=json.loads((r/f'{label}.json').read_text());entry={'label':label,'command':cmd,'cwd':str(cwd),'TMPDIR':str(tmp),'exit_code':p.returncode,'counts':{k:d[k] for k in ('passed','failed','errors','fixture_teardown_failed','session_teardown_failed')},'wall_seconds':time.monotonic()-start,'report_sha256':hashlib.sha256((r/f'{label}.json').read_bytes()).hexdigest()};meta['runs'].append(entry);assert p.returncode==0 and not(r/f'{label}.stderr').stat().st_size;assert not list(tmp.iterdir());assert not [l for l in subprocess.check_output(['ps','-eo','pid,args'],text=True).splitlines() if str(tmp) in l];tmp.rmdir();return {t['name'] for t in d['tests']},entry

for label,path,fn,old,new in [('checker-restored-fast',files[0],'readiness_report_retains_checker_limits','slow','fast'),('pure-demoted-slow',files[1],'lookup_selects_the_named_backend_observation','fast','slow')]:
 text=original[path].decode();node=next(n for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==fn);value=next(k.value for d in node.decorator_list if isinstance(d,ast.Call) for k in d.keywords if k.arg=='mark');assert value.value==old;lines=text.splitlines(keepends=True);line=lines[value.lineno-1];lines[value.lineno-1]=line[:value.col_offset]+f'"{new}"'+line[value.end_col_offset:];(cwd/path).write_text(''.join(lines))
 try:
  names,entry=run('fault-'+label,['--mark','fast']);assert names!=expected;entry.update({'fault':label,'expected_names':sorted(expected),'extra_names':sorted(names-expected),'missing_names':sorted(expected-names),'routing_oracle_rejected':True,'mutated_sha256':hashlib.sha256((cwd/path).read_bytes()).hexdigest()});print(label,'rejected:',entry['extra_names'],entry['missing_names'],flush=True)
 finally:(cwd/path).write_bytes(original[path])
 names,entry=run('restored-'+label,['--mark','fast']);assert names==expected;entry['routing_oracle_passed']=True
names,entry=run('calibration-restored-all',[]);assert names=={t['name'] for t in json.loads((r/'after-typing-all.json').read_text())['tests']};assert len(names)==61;assert subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True)=='';meta['source_restored']=True;(r/'routing-calibration.json').write_text(json.dumps(meta,indent=2)+'\n')
