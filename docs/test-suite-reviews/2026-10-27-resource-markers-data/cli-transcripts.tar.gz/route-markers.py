"""One-off public CLI red/green proof, not a maintained policy engine."""
import ast,hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
R=Path(__file__).parent
FILE=Path('tests/test_typing_compatibility.py');PURE='tests/test_typing_assessment.py'
for sig in (signal.SIGINT,signal.SIGQUIT,signal.SIGHUP):signal.signal(sig,signal.SIG_DFL)
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
original=FILE.read_text();base=json.loads((R/'unchanged-typing-all.json').read_text());all_names={t['name'] for t in base['tests']}
controls={f'{PURE}::{s}' for s in ('consumer_mutation_cannot_change_the_next_observation','duplicate_observations_are_not_silently_selected','infrastructure_failure_is_not_an_empty_assessment','lookup_selects_the_named_backend_observation','missing_observation_cannot_pass_vacuously[missing-name]','missing_observation_cannot_pass_vacuously[missing-second-backend]','missing_observation_cannot_pass_vacuously[unknown-backend]','unowned_diagnostics_cannot_certify_a_clean_case')}
metadata={'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Public CLI routing red/green per named producer; passing CLI reports can still fail the independent routing expectation. Not product-defect or timing evidence.','original_sha256':hashlib.sha256(FILE.read_bytes()).hexdigest(),'runs':[],'cycles':[]}

def run(label,extra,files=None):
 tmp=R/f'q{len(metadata["runs"])}';tmp.mkdir();cmd=[sys.executable,'-m','snektest',*(files or [str(FILE),PURE]),*extra,'--json-output'];start=time.monotonic()
 with (R/f'{label}.json').open('wb') as out,(R/f'{label}.stderr').open('wb') as err:p=subprocess.run(cmd,env={**os.environ,'TMPDIR':str(tmp),'PYTHON_CONTEXT_AWARE_WARNINGS':'1'},stdout=out,stderr=err,check=False)
 report=json.loads((R/f'{label}.json').read_text());counts={k:report[k] for k in ('passed','failed','errors','fixture_teardown_failed','session_teardown_failed')};entry={'label':label,'command':cmd,'exit_code':p.returncode,'counts':counts,'wall_seconds':time.monotonic()-start,'TMPDIR':str(tmp),'report_sha256':hashlib.sha256((R/f'{label}.json').read_bytes()).hexdigest()};metadata['runs'].append(entry)
 assert p.returncode==0 and not any(counts[k] for k in ('failed','errors','fixture_teardown_failed','session_teardown_failed'));assert not(R/f'{label}.stderr').stat().st_size;assert not list(tmp.iterdir());assert not [l for l in subprocess.check_output(['ps','-eo','pid,args'],text=True).splitlines() if str(tmp) in l];tmp.rmdir();return {t['name'] for t in report['tests']}

def marker(fn):
 return next((k.value for d in fn.decorator_list if isinstance(d,ast.Call) and isinstance(d.func,ast.Name) and d.func.id=='test' for k in d.keywords if k.arg=='mark'),None)

def normalize(text):
 tree=ast.parse(text)
 for fn in tree.body:
  if isinstance(fn,(ast.FunctionDef,ast.AsyncFunctionDef)) and fn.name in targets:marker(fn).value='resource-marker'
 return ast.dump(tree,include_attributes=False)

targets=[fn.name for fn in ast.parse(original).body if isinstance(fn,(ast.FunctionDef,ast.AsyncFunctionDef)) and fn.decorator_list and isinstance(marker(fn),ast.Constant) and marker(fn).value=='fast']
assert len(targets)==15
expected_fast={t['name'] for t in json.loads((R/'unchanged-typing-fast.json').read_text())['tests']}
for index,name in enumerate(targets):
 prefix=f'{FILE}::{name}';producer={n for n in all_names if n==prefix or n.startswith(prefix+'[')};assert producer
 red=run(f'route-{index:02d}-red',['--mark','fast']);assert red==expected_fast and controls<=red
 try:assert not red&producer,'Checker-backed producer is still selected by --mark fast'
 except AssertionError as error:failure=str(error)
 else:raise AssertionError('Expected routing red was not reproduced')
 source=FILE.read_text();fn=next(n for n in ast.parse(source).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name);node=marker(fn);assert node.value=='fast' and node.lineno==node.end_lineno;lines=source.splitlines(keepends=True);line=lines[node.lineno-1];assert line[node.col_offset:node.end_col_offset]=='"fast"';lines[node.lineno-1]=line[:node.col_offset]+'"slow"'+line[node.end_col_offset:];FILE.write_text(''.join(lines));assert normalize(original)==normalize(FILE.read_text())
 expected_fast-=producer;green=run(f'route-{index:02d}-green',['--mark','fast']);assert green==expected_fast and controls<=green and not green&producer
 slow=run(f'route-{index:02d}-cold-slow',['--mark','slow'],[prefix]);assert slow==producer
 metadata['cycles'].append({'function':name,'case_names':sorted(producer),'routing_red':failure,'red_report':f'route-{index:02d}-red.json','green_report':f'route-{index:02d}-green.json','cold_slow_report':f'route-{index:02d}-cold-slow.json'});(R/'routing-tdd.json').write_text(json.dumps(metadata,indent=2)+'\n');print(name,'red -> green -> cold slow',len(producer),flush=True)
after=run('after-typing-all',[]);fast=run('after-typing-fast',['--mark','fast']);slow=run('after-typing-slow',['--mark','slow']);assert after==all_names and len(after)==61;assert fast==controls and len(fast)==8;assert len(slow)==53 and not fast&slow and fast|slow==after;metadata['final']={'unfiltered':len(after),'fast':len(fast),'slow':len(slow),'names_unchanged':True,'partition_disjoint_complete':True,'only_marker_ast_changed':normalize(original)==normalize(FILE.read_text()),'source_sha256':hashlib.sha256(FILE.read_bytes()).hexdigest()};(R/'routing-tdd.json').write_text(json.dumps(metadata,indent=2)+'\n');print(metadata['final'],flush=True)
